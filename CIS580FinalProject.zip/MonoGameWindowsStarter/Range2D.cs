﻿

namespace MonoGameWindowsStarter
{
    public struct Range2D
    {
        public int xMin;
        public int xMax;
        public int yMin;
        public int yMax;

        public Range2D(int xmin, int xmax, int ymin, int ymax)
        {
            xMin = xmin;
            xMax = xmax;
            yMin = ymin;
            yMax = ymax;
        }

        public bool inRange(int x, int y)
        {
            return x >= xMin && x <= xMax && y >= yMin && y <= yMax;
        }
    }
}

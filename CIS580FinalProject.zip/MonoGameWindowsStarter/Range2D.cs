﻿

namespace MonoGameWindowsStarter
{
    struct Range2D
    {
        int xMin;
        int xMax;
        int yMin;
        int yMax;
    }
}

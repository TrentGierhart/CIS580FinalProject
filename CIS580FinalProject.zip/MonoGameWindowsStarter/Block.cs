﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace MonoGameWindowsStarter
{
    class Block
    {
        Vector2 pixelPos;
        Vector2 tilePos;
        int pixelWidth;
        int pixelHeight;
        int tileWidth;
        int tileHeight;

        Game1 game1;
        int access; //1 for Player 1 only, 2 for Player 2 only, 0 for any
    }
}

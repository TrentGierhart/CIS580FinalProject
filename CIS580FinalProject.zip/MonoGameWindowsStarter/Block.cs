﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MonoGameWindowsStarter
{
    public class Block
    {
        Vector2 pixelPos;
        public Vector2 tilePos;
        int pixelWidth;
        int pixelHeight;
        public int tileWidth;
        public int tileHeight;
        Texture2D[] textures;
        public int ATI; //Active Texture Index

        Game1 game1;
        public int access; //1 for Player 1 only, 2 for Player 2 only, 0 for neutral

        MouseState mouseState;
        MouseState prevMouseState;

        public Block(Game1 g, Texture2D[] t, Vector2 tPos, int tWidth, int tHeight, int a)
        {
            game1 = g;
            tilePos = tPos;
            pixelPos = new Vector2(tilePos.X * 64, tilePos.Y * 64);
            tileWidth = tWidth;
            pixelWidth = tileWidth * 64;
            tileHeight = tHeight;
            pixelHeight = tHeight * 64;
            textures = t;
            access = a;
            ATI = 0;
        }

        private bool IsMousePositionValid(MouseState mouseState)
        {
            int topRightCornerXPos = (int)pixelPos.X + pixelWidth;
            int bottomLeftCornerYPos = (int)pixelPos.Y + pixelHeight;

            bool xCoordIsValid = false;
            bool yCoordIsValid = false;

            if (mouseState.Position.X > pixelPos.X && mouseState.Position.X < topRightCornerXPos)
            {
                xCoordIsValid = true;
            }

            if (mouseState.Position.Y > pixelPos.Y && mouseState.Position.Y < bottomLeftCornerYPos)
            {
                yCoordIsValid = true;
            }

            return xCoordIsValid && yCoordIsValid;

        }

        public bool IsClicked(MouseState mouseState)
        {
            return mouseState.LeftButton == ButtonState.Pressed && IsMousePositionValid(mouseState);
        }

        public void Update()
        {
            mouseState = Mouse.GetState();
            if ((int)pixelPos.X != (int)tilePos.X * 64 || (int)pixelPos.Y != (int)tilePos.Y * 64)
            {
                pixelPos.X = tilePos.X * 64;
                pixelPos.Y = tilePos.Y * 64;
            }

            if (mouseState.LeftButton == ButtonState.Pressed && 
                prevMouseState.LeftButton == ButtonState.Released && IsClicked(mouseState)
                && (game1.turn == access || access == 0)
                && !game1.map.IsTileTexture((int)tilePos.X,(int)tilePos.Y,game1.texturesTile[2]))
            {
                game1.ResetBackground();
                if (game1.activeBlock == this)
                {
                    game1.activeBlock = null;
                    if (access == 0) ATI -= 5;
                    else ATI -= 1;
                }
                else
                {
                    game1.activeBlock = this;
                    if (access == 0) ATI += 5;
                    else ATI += 1;
                }
            }
            prevMouseState = mouseState;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            var rect = new Rectangle((int)pixelPos.X, (int)pixelPos.Y, pixelWidth, pixelHeight);
            spriteBatch.Draw(textures[ATI], rect, Color.White);
        }
    }
}

﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace MonoGameWindowsStarter
{
    public class Map
    {
        Tile[,] tiles;


        public Map(Tile[,] t)
        {
            tiles = t;
        }

        public void RetextureTileAt(int i, int j, Texture2D t)
        {
            tiles[i, j].texture = t;
        }

        public void SetOccupiedAt(int i, int j, bool o)
        {
            tiles[i, j].occupied = o;
        }

        public bool IsTileTexture(int i, int j, Texture2D texture)
        {
            return tiles[i, j].texture == texture;
        }

        public bool IsTileClicked(int i, int j, MouseState ms)
        {
            return tiles[i, j].IsClicked(ms);
        }

        public Range2D FindOpenTiles(Block b)
        {
            //up
            int offset = 1;
            bool clear = true;
            while (clear)
            {
                if (!tiles[(int)b.tilePos.X, (int)b.tilePos.Y - offset].occupied)
                {
                    for (int i = (int)b.tilePos.X + 1; i < (int)b.tilePos.X + b.tileWidth; i++)
                    {
                        if (tiles[i, (int)b.tilePos.Y - offset].occupied)
                        {
                            clear = false;
                        }
                    }
                    if (clear)
                    {
                        offset++;
                    }
                }
                else
                {
                    clear = false;
                }
            }
            int ymin = (int)b.tilePos.Y - offset + 1;

            //down
            offset = b.tileHeight;
            clear = true;
            while (clear)
            {
                if (!tiles[(int)b.tilePos.X, (int)b.tilePos.Y + offset].occupied)
                {
                    for (int i = (int)b.tilePos.X + 1; i < (int)b.tilePos.X + b.tileWidth; i++)
                    {
                        if (tiles[i, (int)b.tilePos.Y + offset].occupied)
                        {
                            clear = false;
                        }
                    }
                    if (clear)
                    {
                        offset++;
                    }
                }
                else
                {
                    clear = false;
                }
            }
            int ymax = (int)b.tilePos.Y + offset - b.tileHeight;

            //left
            offset = 1;
            clear = true;
            while (clear)
            {
                if ((int)b.tilePos.X - offset < 1 && (int)b.tilePos.Y == 6)
                {
                    clear = false;
                    break;
                }
                if (!tiles[(int)b.tilePos.X - offset, (int)b.tilePos.Y].occupied)
                {
                    for (int j = (int)b.tilePos.Y + 1; j < (int)b.tilePos.Y + b.tileHeight; j++)
                    {
                        if (tiles[(int)b.tilePos.X - offset, j].occupied)
                        {
                            clear = false;
                        }
                    }
                    if (clear)
                    {
                        offset++;
                    }
                }
                else
                {
                    clear = false;
                }
            }
            int xmin = (int)b.tilePos.X - offset + 1;

            //right
            offset = b.tileWidth;
            clear = true;
            while (clear)
            {
                if ((int)b.tilePos.X + offset > 15 && (int)b.tilePos.Y == 6)
                {
                    if (b.access != 1)
                    {
                        offset--;
                    }
                    clear = false;
                    break;
                }
                if (!tiles[(int)b.tilePos.X + offset, (int)b.tilePos.Y].occupied)
                {
                    for (int j = (int)b.tilePos.Y + 1; j < (int)b.tilePos.Y + b.tileHeight; j++)
                    {
                        if (tiles[(int)b.tilePos.X + offset, j].occupied)
                        {
                            clear = false;
                        }
                    }
                    if (clear)
                    {
                        offset++;
                    }
                }
                else
                {
                    clear = false;
                }
            }
            int xmax = (int)b.tilePos.X + offset - b.tileWidth;

            return new Range2D(xmin, xmax, ymin, ymax);
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach(Tile t in tiles)
            {
                t.Draw(spriteBatch);
            }
        }
    }
}

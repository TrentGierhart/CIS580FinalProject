﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoGameWindowsStarter
{
    class Map
    {
        Tile[][] tiles;
        int tileWidth;
        int tileHeight;

    }
}

﻿using Microsoft.Xna.Framework.Graphics;
using System;

namespace MonoGameWindowsStarter
{
    class Map
    {
        Tile[,] tiles;


        public Map(Tile[,] t)
        {
            tiles = t;
        }

        public void ReplaceTileAt(int i, int j, Tile t)
        {
            tiles[i, j] = t;
        }

        public void SetOccupiedAt(int i, int j, bool o)
        {
            tiles[i, j].occupied = o;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach(Tile t in tiles)
            {
                t.Draw(spriteBatch);
            }
        }
    }
}

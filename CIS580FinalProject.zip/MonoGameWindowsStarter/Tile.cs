﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MonoGameWindowsStarter
{
    public class Tile
    {
        Vector2 pos;
        public bool occupied;
        public Texture2D texture;

        public Tile(Vector2 p, bool o, Texture2D t)
        {
            pos = p;
            occupied = o;
            texture = t;
        }

        private bool IsMousePositionValid(MouseState mouseState)
        {
            int topRightCornerXPos = (int)pos.X + 64;
            int bottomLeftCornerYPos = (int)pos.Y + 64;

            bool xCoordIsValid = false;
            bool yCoordIsValid = false;

            if (mouseState.Position.X > pos.X && mouseState.Position.X < topRightCornerXPos)
            {
                xCoordIsValid = true;
            }

            if (mouseState.Position.Y > pos.Y && mouseState.Position.Y < bottomLeftCornerYPos)
            {
                yCoordIsValid = true;
            }

            return xCoordIsValid && yCoordIsValid;

        }

        public bool IsClicked(MouseState mouseState)
        {
            return mouseState.LeftButton == ButtonState.Pressed && IsMousePositionValid(mouseState);
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            var rect = new Rectangle((int)pos.X, (int)pos.Y, 64, 64);
            spriteBatch.Draw(texture, rect, Color.White);
        }
    }
}

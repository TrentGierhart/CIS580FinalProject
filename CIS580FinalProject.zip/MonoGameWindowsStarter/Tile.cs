﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MonoGameWindowsStarter
{
    class Tile
    {
        Vector2 pos;
        public bool occupied;
        Texture2D texture;

        public Tile(Vector2 p, bool o, Texture2D t)
        {
            pos = p;
            occupied = o;
            texture = t;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            var rect = new Rectangle((int)pos.X, (int)pos.Y, 64, 64);
            spriteBatch.Draw(texture, rect, Color.White);
        }
    }
}

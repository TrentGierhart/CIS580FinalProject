﻿using Microsoft.Xna.Framework;

namespace MonoGameWindowsStarter
{
    class Tile
    {
        Vector2 pos;
        public bool occupied;

        public Tile(Vector2 p, bool o)
        {
            pos = p;
            occupied = o;
        }
    }
}

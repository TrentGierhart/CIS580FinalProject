﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

namespace MonoGameWindowsStarter
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        public Random Random = new Random();

        Map map;
        List<Block> blocks = new List<Block>();

        Texture2D[] textures1x2 = new Texture2D[10];
        Texture2D[] textures1x3 = new Texture2D[10];
        Texture2D[] textures1x4 = new Texture2D[10];
        Texture2D[] textures2x1 = new Texture2D[10];
        Texture2D[] textures3x1 = new Texture2D[10];
        Texture2D[] textures4x1 = new Texture2D[10];

        Texture2D[] texturesP1 = new Texture2D[2];
        Texture2D[] texturesP2 = new Texture2D[2];

        Texture2D[] texturesTile = new Texture2D[8];

        KeyboardState oldKeyboardState;
        KeyboardState newKeyboardState;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // Set the game screen size
            graphics.PreferredBackBufferWidth = 1024;
            graphics.PreferredBackBufferHeight = 768;
            graphics.ApplyChanges();
            IsMouseVisible = true;
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //--------Load the textures for the neutral blocks-----------------
            //1x2
            textures1x2[0] = Content.Load<Texture2D>("1x2full");
            for (int i = 1; i <= 4; i++)
            {
                textures1x2[i] = Content.Load<Texture2D>("1x2c"+i);
            }
            textures1x2[5] = Content.Load<Texture2D>("1x2full_selected");
            for (int i = 1; i <= 4; i++)
            {
                textures1x2[5 + i] = Content.Load<Texture2D>("1x2c"+i+"_selected");
            }
            //1x3
            textures1x3[0] = Content.Load<Texture2D>("1x3full");
            for (int i = 1; i <= 4; i++)
            {
                textures1x3[i] = Content.Load<Texture2D>("1x3c" + i);
            }
            textures1x3[5] = Content.Load<Texture2D>("1x3full_selected");
            for (int i = 1; i <= 4; i++)
            {
                textures1x3[5 + i] = Content.Load<Texture2D>("1x3c" + i + "_selected");
            }
            //1x4
            textures1x4[0] = Content.Load<Texture2D>("1x4full");
            for (int i = 1; i <= 4; i++)
            {
                textures1x4[i] = Content.Load<Texture2D>("1x4c" + i);
            }
            textures1x4[5] = Content.Load<Texture2D>("1x4full_selected");
            for (int i = 1; i <= 4; i++)
            {
                textures1x4[5 + i] = Content.Load<Texture2D>("1x4c" + i + "_selected");
            }
            //2x1
            textures2x1[0] = Content.Load<Texture2D>("2x1full");
            for (int i = 1; i <= 4; i++)
            {
                textures2x1[i] = Content.Load<Texture2D>("2x1c" + i);
            }
            textures2x1[5] = Content.Load<Texture2D>("2x1full_selected");
            for (int i = 1; i <= 4; i++)
            {
                textures2x1[5 + i] = Content.Load<Texture2D>("2x1c" + i + "_selected");
            }
            //3x1
            textures3x1[0] = Content.Load<Texture2D>("3x1full");
            for (int i = 1; i <= 4; i++)
            {
                textures3x1[i] = Content.Load<Texture2D>("3x1c" + i);
            }
            textures3x1[5] = Content.Load<Texture2D>("3x1full_selected");
            for (int i = 1; i <= 4; i++)
            {
                textures3x1[5 + i] = Content.Load<Texture2D>("3x1c" + i + "_selected");
            }
            //4x1
            textures4x1[0] = Content.Load<Texture2D>("4x1full");
            for (int i = 1; i <= 4; i++)
            {
                textures4x1[i] = Content.Load<Texture2D>("4x1c" + i);
            }
            textures4x1[5] = Content.Load<Texture2D>("4x1full_selected");
            for (int i = 1; i <= 4; i++)
            {
                textures4x1[5 + i] = Content.Load<Texture2D>("4x1c" + i + "_selected");
            }
            //-------------------------------------------------

            //-----Load the textures for the player blocks-----
            texturesP1[0] = Content.Load<Texture2D>("Player1");
            texturesP1[1] = Content.Load<Texture2D>("Player1_selected");
            texturesP2[0] = Content.Load<Texture2D>("Player2");
            texturesP2[1] = Content.Load<Texture2D>("Player2_selected");
            //-------------------------------------------------

            //-------Load the textures for the tiles-----------
            texturesTile[0] = Content.Load<Texture2D>("wall");
            texturesTile[1] = Content.Load<Texture2D>("background");
            texturesTile[2] = Content.Load<Texture2D>("background_clickdest");
            texturesTile[3] = Content.Load<Texture2D>("background_dest");
            texturesTile[4] = Content.Load<Texture2D>("player1win");
            texturesTile[5] = Content.Load<Texture2D>("player1win_clickdest");
            texturesTile[6] = Content.Load<Texture2D>("player2win");
            texturesTile[7] = Content.Load<Texture2D>("player2win_clickdest");
            //-------------------------------------------------

            //--------------Initialize the Map-----------------
            Tile[,] tiles = new Tile[16, 12];
            //outer walls
            for (int i = 0; i < 16; i++)
            {
                tiles[i, 0] = new Tile(new Vector2(i * 64, 0), true, texturesTile[0]);
            }
            for (int i = 0; i < 16; i++)
            {
                tiles[i, 11] = new Tile(new Vector2(i * 64, 704), true, texturesTile[0]);
            }
            for (int j = 0; j < 6; j++)
            {
                tiles[0, j] = new Tile(new Vector2(0, j * 64), true, texturesTile[0]);
            }
            tiles[0, 6] = new Tile(new Vector2(0, 384), false, texturesTile[6]);
            for (int j = 7; j < 12; j++)
            {
                tiles[0, j] = new Tile(new Vector2(0, j * 64), true, texturesTile[0]);
            }
            for (int j = 0; j < 6; j++)
            {
                tiles[15, j] = new Tile(new Vector2(960, j * 64), true, texturesTile[0]);
            }
            tiles[15, 6] = new Tile(new Vector2(960, 384), false, texturesTile[4]);
            for (int j = 7; j < 12; j++)
            {
                tiles[15, j] = new Tile(new Vector2(960, j * 64), true, texturesTile[0]);
            }
            //remaining background
            for (int i = 1; i < 15; i++)
            {
                for (int j = 1; j < 11; j++)
                {
                    tiles[i, j] = new Tile(new Vector2(i * 64, j * 64), false, texturesTile[1]);
                }
            }
            map = new Map(tiles);
            //-------------------------------------------------

            //-------------Initialize the puzzle---------------
            blocks.Add(new Block(this, texturesP1, new Vector2(1, 1), 2, 1, 1));
            blocks.Add(new Block(this, texturesP2, new Vector2(13, 1), 2, 1, 2));
            blocks.Add(new Block(this, textures1x2, new Vector2(3, 1), 2, 1, 0));
            blocks.Add(new Block(this, textures2x1, new Vector2(5, 1), 1, 2, 0));
            blocks.Add(new Block(this, textures4x1, new Vector2(7, 1), 1, 4, 0));
            blocks.Add(new Block(this, textures4x1, new Vector2(9, 1), 1, 4, 0));
            blocks.Add(new Block(this, textures1x2, new Vector2(11, 1), 2, 1, 0));
            blocks.Add(new Block(this, textures1x2, new Vector2(1, 2), 2, 1, 0));
            blocks.Add(new Block(this, textures1x2, new Vector2(13, 2), 2, 1, 0));
            blocks.Add(new Block(this, textures1x3, new Vector2(1, 4), 3, 1, 0));
            blocks.Add(new Block(this, textures2x1, new Vector2(4, 4), 1, 2, 0));
            blocks.Add(new Block(this, textures1x3, new Vector2(12, 4), 3, 1, 0));
            blocks.Add(new Block(this, textures3x1, new Vector2(1, 5), 1, 3, 0));
            blocks.Add(new Block(this, textures1x4, new Vector2(6, 5), 4, 1, 0));
            blocks.Add(new Block(this, textures3x1, new Vector2(14, 5), 1, 3, 0));
            blocks.Add(new Block(this, textures1x4, new Vector2(5, 6), 4, 1, 0));
            blocks.Add(new Block(this, textures1x2, new Vector2(3, 7), 2, 1, 0));
            blocks.Add(new Block(this, textures4x1, new Vector2(5, 7), 1, 4, 0));
            blocks.Add(new Block(this, textures4x1, new Vector2(7, 7), 1, 4, 0));
            blocks.Add(new Block(this, textures2x1, new Vector2(9, 7), 1, 2, 0));
            blocks.Add(new Block(this, textures2x1, new Vector2(11, 7), 1, 2, 0));
            blocks.Add(new Block(this, textures3x1, new Vector2(10, 8), 1, 3, 0));
            blocks.Add(new Block(this, textures1x3, new Vector2(12, 8), 3, 1, 0));
            blocks.Add(new Block(this, textures1x3, new Vector2(1, 9), 3, 1, 0));
            blocks.Add(new Block(this, textures1x3, new Vector2(12, 10), 3, 1, 0));

            foreach (Block b in blocks)
            {
                map.SetOccupiedAt((int)b.tilePos.X, (int)b.tilePos.Y, true);
            }
            //-------------------------------------------------
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            newKeyboardState = Keyboard.GetState();

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            if (newKeyboardState.IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            oldKeyboardState = newKeyboardState;
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Tan);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            map.Draw(spriteBatch);
            foreach(Block b in blocks)
            {
                b.Draw(spriteBatch);
            }
            
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}

﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

namespace MonoGameWindowsStarter
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        public Random Random = new Random();

        public Map map;
        List<Block> blocks = new List<Block>();
        public Block activeBlock = null;
        public int turn;
        public bool gameOver = false;

        Texture2D[] texturesTurn = new Texture2D[2];
        Texture2D[] texturesWinMsg = new Texture2D[2];

        Texture2D[] textures1x2 = new Texture2D[10];
        Texture2D[] textures1x3 = new Texture2D[10];
        Texture2D[] textures1x4 = new Texture2D[10];
        Texture2D[] textures2x1 = new Texture2D[10];
        Texture2D[] textures3x1 = new Texture2D[10];
        Texture2D[] textures4x1 = new Texture2D[10];

        Texture2D[] texturesP1 = new Texture2D[2];
        Texture2D[] texturesP2 = new Texture2D[2];

        public Texture2D[] texturesTile = new Texture2D[8];

        MouseState mouseState;
        MouseState prevMouseState;

        KeyboardState oldKeyboardState;
        KeyboardState newKeyboardState;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // Set the game screen size
            graphics.PreferredBackBufferWidth = 1024;
            graphics.PreferredBackBufferHeight = 768;
            graphics.ApplyChanges();
            turn = 1;
            IsMouseVisible = true;
            prevMouseState = Mouse.GetState();
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //--------Load the textures for the neutral blocks-----------------
            //1x2
            textures1x2[0] = Content.Load<Texture2D>("1x2full");
            for (int i = 1; i <= 4; i++)
            {
                textures1x2[i] = Content.Load<Texture2D>("1x2c"+i);
            }
            textures1x2[5] = Content.Load<Texture2D>("1x2full_selected");
            for (int i = 1; i <= 4; i++)
            {
                textures1x2[5 + i] = Content.Load<Texture2D>("1x2c"+i+"_selected");
            }
            //1x3
            textures1x3[0] = Content.Load<Texture2D>("1x3full");
            for (int i = 1; i <= 4; i++)
            {
                textures1x3[i] = Content.Load<Texture2D>("1x3c" + i);
            }
            textures1x3[5] = Content.Load<Texture2D>("1x3full_selected");
            for (int i = 1; i <= 4; i++)
            {
                textures1x3[5 + i] = Content.Load<Texture2D>("1x3c" + i + "_selected");
            }
            //1x4
            textures1x4[0] = Content.Load<Texture2D>("1x4full");
            for (int i = 1; i <= 4; i++)
            {
                textures1x4[i] = Content.Load<Texture2D>("1x4c" + i);
            }
            textures1x4[5] = Content.Load<Texture2D>("1x4full_selected");
            for (int i = 1; i <= 4; i++)
            {
                textures1x4[5 + i] = Content.Load<Texture2D>("1x4c" + i + "_selected");
            }
            //2x1
            textures2x1[0] = Content.Load<Texture2D>("2x1full");
            for (int i = 1; i <= 4; i++)
            {
                textures2x1[i] = Content.Load<Texture2D>("2x1c" + i);
            }
            textures2x1[5] = Content.Load<Texture2D>("2x1full_selected");
            for (int i = 1; i <= 4; i++)
            {
                textures2x1[5 + i] = Content.Load<Texture2D>("2x1c" + i + "_selected");
            }
            //3x1
            textures3x1[0] = Content.Load<Texture2D>("3x1full");
            for (int i = 1; i <= 4; i++)
            {
                textures3x1[i] = Content.Load<Texture2D>("3x1c" + i);
            }
            textures3x1[5] = Content.Load<Texture2D>("3x1full_selected");
            for (int i = 1; i <= 4; i++)
            {
                textures3x1[5 + i] = Content.Load<Texture2D>("3x1c" + i + "_selected");
            }
            //4x1
            textures4x1[0] = Content.Load<Texture2D>("4x1full");
            for (int i = 1; i <= 4; i++)
            {
                textures4x1[i] = Content.Load<Texture2D>("4x1c" + i);
            }
            textures4x1[5] = Content.Load<Texture2D>("4x1full_selected");
            for (int i = 1; i <= 4; i++)
            {
                textures4x1[5 + i] = Content.Load<Texture2D>("4x1c" + i + "_selected");
            }
            //-------------------------------------------------

            //-----Load the textures for the player blocks-----
            texturesP1[0] = Content.Load<Texture2D>("Player1");
            texturesP1[1] = Content.Load<Texture2D>("Player1_selected");
            texturesP2[0] = Content.Load<Texture2D>("Player2");
            texturesP2[1] = Content.Load<Texture2D>("Player2_selected");
            //-------------------------------------------------

            //---Load the textures for the turn indicator------
            texturesTurn[0] = Content.Load<Texture2D>("turn1");
            texturesTurn[1] = Content.Load<Texture2D>("turn2");
            //-------------------------------------------------

            //---Load the textures for the win message---------
            texturesWinMsg[0] = Content.Load<Texture2D>("player1msg");
            texturesWinMsg[1] = Content.Load<Texture2D>("player2msg");
            //-------------------------------------------------

            //-------Load the textures for the tiles-----------
            texturesTile[0] = Content.Load<Texture2D>("wall");
            texturesTile[1] = Content.Load<Texture2D>("background");
            texturesTile[2] = Content.Load<Texture2D>("background_clickdest");
            texturesTile[3] = Content.Load<Texture2D>("background_dest");
            texturesTile[4] = Content.Load<Texture2D>("player1win");
            texturesTile[5] = Content.Load<Texture2D>("player1win_clickdest");
            texturesTile[6] = Content.Load<Texture2D>("player2win");
            texturesTile[7] = Content.Load<Texture2D>("player2win_clickdest");
            //-------------------------------------------------

            //--------------Initialize the Map-----------------
            Tile[,] tiles = new Tile[16, 12];
            //outer walls
            for (int i = 0; i < 16; i++)
            {
                tiles[i, 0] = new Tile(new Vector2(i * 64, 0), true, texturesTile[0]);
            }
            for (int i = 0; i < 16; i++)
            {
                tiles[i, 11] = new Tile(new Vector2(i * 64, 704), true, texturesTile[0]);
            }
            for (int j = 0; j < 6; j++)
            {
                tiles[0, j] = new Tile(new Vector2(0, j * 64), true, texturesTile[0]);
            }
            tiles[0, 6] = new Tile(new Vector2(0, 384), false, texturesTile[6]);
            for (int j = 7; j < 12; j++)
            {
                tiles[0, j] = new Tile(new Vector2(0, j * 64), true, texturesTile[0]);
            }
            for (int j = 0; j < 6; j++)
            {
                tiles[15, j] = new Tile(new Vector2(960, j * 64), true, texturesTile[0]);
            }
            tiles[15, 6] = new Tile(new Vector2(960, 384), false, texturesTile[4]);
            for (int j = 7; j < 12; j++)
            {
                tiles[15, j] = new Tile(new Vector2(960, j * 64), true, texturesTile[0]);
            }
            //remaining background
            for (int i = 1; i < 15; i++)
            {
                for (int j = 1; j < 11; j++)
                {
                    tiles[i, j] = new Tile(new Vector2(i * 64, j * 64), false, texturesTile[1]);
                }
            }
            map = new Map(tiles);
            //-------------------------------------------------

            //-------------Initialize the puzzle---------------
            blocks.Add(new Block(this, texturesP1, new Vector2(1, 1), 2, 1, 1));
            blocks.Add(new Block(this, texturesP2, new Vector2(13, 1), 2, 1, 2));
            blocks.Add(new Block(this, textures1x2, new Vector2(3, 1), 2, 1, 0));
            blocks.Add(new Block(this, textures2x1, new Vector2(5, 1), 1, 2, 0));
            blocks.Add(new Block(this, textures4x1, new Vector2(7, 1), 1, 4, 0));
            blocks.Add(new Block(this, textures4x1, new Vector2(9, 1), 1, 4, 0));
            blocks.Add(new Block(this, textures1x2, new Vector2(11, 1), 2, 1, 0));
            blocks.Add(new Block(this, textures1x2, new Vector2(1, 2), 2, 1, 0));
            blocks.Add(new Block(this, textures1x2, new Vector2(13, 2), 2, 1, 0));
            blocks.Add(new Block(this, textures1x3, new Vector2(1, 4), 3, 1, 0));
            blocks.Add(new Block(this, textures2x1, new Vector2(4, 4), 1, 2, 0));
            blocks.Add(new Block(this, textures1x3, new Vector2(12, 4), 3, 1, 0));
            blocks.Add(new Block(this, textures3x1, new Vector2(1, 5), 1, 3, 0));
            blocks.Add(new Block(this, textures1x4, new Vector2(6, 5), 4, 1, 0));
            blocks.Add(new Block(this, textures3x1, new Vector2(14, 5), 1, 3, 0));
            blocks.Add(new Block(this, textures1x4, new Vector2(5, 6), 4, 1, 0));
            blocks.Add(new Block(this, textures1x2, new Vector2(3, 7), 2, 1, 0));
            blocks.Add(new Block(this, textures4x1, new Vector2(5, 7), 1, 4, 0));
            blocks.Add(new Block(this, textures4x1, new Vector2(7, 7), 1, 4, 0));
            blocks.Add(new Block(this, textures2x1, new Vector2(9, 7), 1, 2, 0));
            blocks.Add(new Block(this, textures2x1, new Vector2(11, 7), 1, 2, 0));
            blocks.Add(new Block(this, textures3x1, new Vector2(10, 8), 1, 3, 0));
            blocks.Add(new Block(this, textures1x3, new Vector2(12, 8), 3, 1, 0));
            blocks.Add(new Block(this, textures1x3, new Vector2(1, 9), 3, 1, 0));
            blocks.Add(new Block(this, textures1x3, new Vector2(12, 10), 3, 1, 0));

            foreach (Block b in blocks)
            {
                for (int i = (int)b.tilePos.X; i < (int)b.tilePos.X + b.tileWidth; i++)
                {
                    for (int j = (int)b.tilePos.Y; j < (int)b.tilePos.Y + b.tileHeight; j++)
                    {
                        map.SetOccupiedAt(i, j, true);
                    }
                }
            }
            //-------------------------------------------------
        }

        public void ResetBackground()
        {
            for (int i = 1; i < 15; i++)
            {
                for (int j = 1; j < 11; j++)
                {
                    map.RetextureTileAt(i, j, texturesTile[1]);
                }
            }
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            newKeyboardState = Keyboard.GetState();
            mouseState = Mouse.GetState();

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            if (newKeyboardState.IsKeyDown(Keys.Escape))
                Exit();


            // TODO: Add your update logic here
            foreach (Block b in blocks)
            {
                b.Update();
            }

            if (gameOver) return;

            if (activeBlock != null)
            {
                foreach (Block b in blocks)
                {
                    if (b.access == 0)
                    {
                        if (b != activeBlock && b.ATI >= 5)
                        {
                            b.ATI -= 5;
                        }
                    }
                    else
                    {
                        if (b != activeBlock && b.ATI != 0)
                        {
                            b.ATI = 0;
                        }
                    }
                }

                Range2D openTiles = map.FindOpenTiles(activeBlock);
                map.RetextureTileAt(0, 6, texturesTile[6]);
                for (int i = openTiles.xMin; i <= openTiles.xMax; i++)
                {
                    if (i == 0 && (int)activeBlock.tilePos.Y == 6)
                    {
                        map.RetextureTileAt(i, (int)activeBlock.tilePos.Y, texturesTile[7]);
                    }
                    else
                    {
                        map.RetextureTileAt(i, (int)activeBlock.tilePos.Y, texturesTile[2]);
                    }

                    for (int j = (int)activeBlock.tilePos.Y + 1; 
                        j < (int)activeBlock.tilePos.Y + activeBlock.tileHeight; j++)
                    {
                        if (map.IsTileTexture(i, j, texturesTile[1]))
                        {
                            map.RetextureTileAt(i, j, texturesTile[3]);
                        }
                    }
                }
                for (int i = openTiles.xMax; i < openTiles.xMax + activeBlock.tileWidth; i++)
                {
                    if (map.IsTileTexture(i, (int)activeBlock.tilePos.Y, texturesTile[1]))
                    {
                        map.RetextureTileAt(i, (int)activeBlock.tilePos.Y, texturesTile[3]);
                    }
                }
                for (int j = openTiles.yMin; j <= openTiles.yMax; j++)
                {
                    map.RetextureTileAt((int)activeBlock.tilePos.X, j, texturesTile[2]);
                    for (int i = (int)activeBlock.tilePos.X + 1;
                        i < (int)activeBlock.tilePos.X + activeBlock.tileWidth; i++)
                    {
                        if (map.IsTileTexture(i, j, texturesTile[1]))
                        {
                            map.RetextureTileAt(i, j, texturesTile[3]);
                        }
                    }
                }
                for (int j = openTiles.yMax; j < openTiles.yMax + activeBlock.tileHeight; j++)
                {
                    if (map.IsTileTexture((int)activeBlock.tilePos.X, j, texturesTile[1]))
                    {
                        map.RetextureTileAt((int)activeBlock.tilePos.X, j, texturesTile[3]);
                    }
                }
                map.RetextureTileAt((int)activeBlock.tilePos.X, (int)activeBlock.tilePos.Y, texturesTile[1]);


                if (map.IsTileClicked(0, 6, mouseState) && map.IsTileTexture(0, 6, texturesTile[7]) &&
                    prevMouseState.RightButton == ButtonState.Released && activeBlock.access == 2)
                {
                    activeBlock.tilePos = new Vector2(0, 6);
                    gameOver = true;
                }


                for (int i = 1; i < 15; i++)
                {
                    for (int j = 1; j < 11; j++)
                    {
                        if (map.IsTileClicked(i, j, mouseState) && 
                            map.IsTileTexture(i, j, texturesTile[2]) &&
                            prevMouseState.RightButton == ButtonState.Released)
                        {
                            for (int k = (int)activeBlock.tilePos.X; k < (int)activeBlock.tilePos.X + 
                                activeBlock.tileWidth; k++)
                            {
                                for (int q = (int)activeBlock.tilePos.Y; q < (int)activeBlock.tilePos.Y +
                                    activeBlock.tileHeight; q++)
                                {
                                    map.SetOccupiedAt(k, q, false);
                                }
                            }
                            activeBlock.tilePos = new Vector2(i, j);
                            if (activeBlock.access == 1 && (int)activeBlock.tilePos.X == 14
                                 && (int)activeBlock.tilePos.Y == 6)
                            {
                                gameOver = true;
                            }
                            if (activeBlock.ATI == 9 || activeBlock.ATI == 4)
                            {
                                blocks.Remove(activeBlock);
                            }
                            else
                            {
                                activeBlock.ATI++;
                                for (int k = (int)activeBlock.tilePos.X; k < (int)activeBlock.tilePos.X +
                                    activeBlock.tileWidth; k++)
                                {
                                    for (int q = (int)activeBlock.tilePos.Y; q < (int)activeBlock.tilePos.Y
                                        + activeBlock.tileHeight; q++)
                                    {
                                        map.SetOccupiedAt(k, q, true);
                                    }
                                }
                            }
                            if (activeBlock.access == 0) activeBlock.ATI -= 5;
                            else activeBlock.ATI -= 1;
                            activeBlock = null;
                            ResetBackground();
                            if (turn == 1 && !gameOver) turn = 2;
                            else turn = 1;
                        }
                    }
                }               
            }

            prevMouseState = mouseState;
            oldKeyboardState = newKeyboardState;
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Tan);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            map.Draw(spriteBatch);
            foreach(Block b in blocks)
            {
                b.Draw(spriteBatch);
            }
            var rect = new Rectangle(448, 0, 128, 64);
            spriteBatch.Draw(texturesTurn[turn - 1], rect, Color.White);
            if (gameOver)
            {
                spriteBatch.Draw(texturesWinMsg[turn - 1], new Rectangle(0, 0, 1024, 768), Color.White);
            }
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
